python -m manydepth2.evaluate_depth_many \
    --data_path /root/autodl-tmp/kai/data/1_mgdepth/KITTI  \
    --load_weights_folder logs/models_many/models/weights \
    --eval_mono 
