import numpy as np
import cv2
import torch
import torch.nn.functional as F
from core_gm.gmflow.gmflow.gmflow import GMFlow
from torch import nn
import torchvision.transforms.functional as TF
class BackprojectDepth(nn.Module):
    """Layer to transform a depth image into a point cloud
    """
    def __init__(self, batch_size, height, width):
        super(BackprojectDepth, self).__init__()
        self.batch_size = batch_size
        self.height = height
        self.width = width
        meshgrid = np.meshgrid(range(self.width), range(self.height), indexing='xy')
        self.id_coords = np.stack(meshgrid, axis=0).astype(np.float32)
        self.id_coords = nn.Parameter(torch.from_numpy(self.id_coords),
                                      requires_grad=False)
        self.ones = nn.Parameter(torch.ones(self.batch_size, 1, self.height * self.width),
                                 requires_grad=False)
        self.pix_coords = torch.unsqueeze(torch.stack(
            [self.id_coords[0].view(-1), self.id_coords[1].view(-1)], 0), 0)
        self.pix_coords = self.pix_coords.repeat(batch_size, 1, 1)
        self.pix_coords = nn.Parameter(torch.cat([self.pix_coords, self.ones], 1),
                                       requires_grad=False) # B, 3, H, W
    def forward(self, depth, inv_K):
        batch_size = depth.size(0)
        cam_points = torch.matmul(inv_K[:, :3, :3], self.pix_coords[:batch_size])
        cam_points = depth.view(batch_size, 1, -1) * cam_points
        cam_points = torch.cat([cam_points, self.ones[:batch_size]], 1)
        return cam_points

class Project3D(nn.Module):
    """Layer which projects 3D points into a camera with intrinsics K and at position T
    """
    def __init__(self, batch_size, height, width, eps=1e-7):
        super(Project3D, self).__init__()
        self.batch_size = batch_size
        self.height = height
        self.width = width
        self.eps = eps
    def forward(self, points, K, T):
        batch_size = points.size(0)
        P = torch.matmul(K, T)[:, :3, :]
        cam_points = torch.matmul(P, points)
        pix_coords = cam_points[:, :2, :] / (cam_points[:, 2, :].unsqueeze(1) + self.eps)
        pix_coords = pix_coords.view(batch_size, 2, self.height, self.width)
        pix_coords = pix_coords.permute(0, 2, 3, 1)
        _pix_coords_ = torch.clone(pix_coords)
        _pix_coords_[..., 0] /= self.width - 1
        _pix_coords_[..., 1] /= self.height - 1
        _pix_coords_ = (_pix_coords_ - 0.5) * 2
        return _pix_coords_, pix_coords

class OFRMask(nn.Module):
    def __init__(self,feature_channels = 128,num_scales = 1, upsample_factor = 8,
                 num_head = 1,attention_type = 'swin',ffn_dim_expansion = 4, num_transformer_layers = 6,
                 batch_size=12,matching_height=192,matching_width=640):
        super().__init__()
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model_gmflow = GMFlow(feature_channels=feature_channels,
                                   num_scales=num_scales,
                                   upsample_factor=upsample_factor,
                                   num_head=num_head,
                                   attention_type=attention_type,
                                   ffn_dim_expansion=ffn_dim_expansion,
                                   num_transformer_layers=num_transformer_layers).to(self.device)
        self.attn_splits_list = [2]
        self.corr_radius_list = [-1]
        self.prop_radius_list = [-1]
        self.frame_ids=[0,1]
        address = '/home/jsw/pretrained/gmflow_sintel-0c07dcb3.pth'
        checkpoint = torch.load(address)
        weights = checkpoint['model'] if 'model' in checkpoint else checkpoint
        self.model_gmflow.load_state_dict(weights)
        self.model_gmflow.eval()
        for param in self.model_gmflow.parameters():
            param.requires_grad = False
        self.batch_size = batch_size
        self.matching_height = matching_height
        self.matching_width = matching_width
        # ^^^^^^^^^^^^^^^^^^^^^^ Modifying here ^^^^^^^^^^^^^^^^^^^^^^
        self.backprojector_batch = BackprojectDepth(batch_size=self.batch_size,
                                              height=self.matching_height,
                                              width=self.matching_width)
        self.projector_batch = Project3D(batch_size=self.batch_size,
                                   height=self.matching_height,
                                   width=self.matching_width)
    def invert_flow(self, fwd_flow, segmentation):
        # Get the backward optical flow.
        B, _, H, W = fwd_flow.shape
        grid_y, grid_x = torch.meshgrid(torch.arange(H), torch.arange(W), indexing='ij')
        grid = torch.stack((grid_x, grid_y), dim=0).float().to(fwd_flow.device)  # Shape (2, H, W)
        grid = grid.unsqueeze(0).repeat(B, 1, 1, 1)
        coords = grid + fwd_flow  # Shape (B, 2, H, W)
        bwd_flow = torch.zeros_like(fwd_flow)
        seg_ref = torch.zeros_like(segmentation)
        coords = torch.round(coords).long()
        grid = grid.long()
        coords[:, 0].clamp_(0, W - 1)
        coords[:, 1].clamp_(0, H - 1)
        for b in range(B):
            bwd_flow[b, :, coords[b, 1], coords[b, 0]] = - fwd_flow[b, :, grid[b,1], grid[b,0]]
            seg_ref[b, :, coords[b, 1], coords[b, 0]] = segmentation[b, :, grid[b,1], grid[b,0]]
        return bwd_flow, seg_ref
    def warping(self, lookup_images, current_image, flow_bwd, seg_ref):
        ref_image = F.interpolate(lookup_images[:, 0], scale_factor=1/4, mode='bilinear', align_corners=False)
        cur_image = F.interpolate(current_image, scale_factor=1/4, mode='bilinear', align_corners=False)
        B, _, H, W = flow_bwd.shape
        grid_y, grid_x = torch.meshgrid(torch.arange(H), torch.arange(W), indexing='ij')
        grid = torch.stack((grid_x, grid_y), dim=0).float().to(flow_bwd.device)
        grid = grid.unsqueeze(0).repeat(B, 1, 1, 1)
        new_coords = grid + flow_bwd
        new_coords[:, 0, :, :] = (new_coords[:, 0, :, :] / (W - 1)) * 2 - 1
        new_coords[:, 1, :, :] = (new_coords[:, 1, :, :] / (H - 1)) * 2 - 1
        new_coords = new_coords.permute(0, 2, 3, 1)  # Shape (1, H, W, 2)
        static_reference_dyn = F.grid_sample(cur_image, new_coords, mode='bilinear', padding_mode='zeros', align_corners=True)
        new_static_reference = ref_image*(~seg_ref) + static_reference_dyn*seg_ref
        return new_static_reference
    def normalize_check_flow(self, flow):
        min_val = torch.min(flow)
        max_val = torch.max(flow)
        normalized_flow = (flow - min_val) / (max_val - min_val)
        return normalized_flow

    # def normalize_flow(self, flow):
    #     min_val = torch.min(flow)
    #     max_val = torch.max(flow)
    #     normalized_flow = (flow - min_val) / (max_val - min_val)
    #     return normalized_flow
    #
    # import numpy as np

    def normalize_flow(self,flow):
        """
        flow: [H, W, 2] numpy array, u = flow[..., 0], v = flow[..., 1]
        return: normalized flow with same shape, in [-1, 1]
        """
        # u, v = flow[:, 0], flow[:, 1]
        #  np.sqrt(u ** 2 + v ** 2)
        magnitude = torch.norm(flow, dim=1, keepdim=True)
        # max_mag = np.max(magnitude)
        # if max_mag > 0:
        flow = flow / magnitude  # 现在每个向量最大长度为1
        return flow
    def compute_dynamic_flow(self, lookup_pose, _flow, depth, _K, _invK):
        flow = _flow[:depth.size(0)]
        flow=self.normalize_flow(flow)
        # look = (flow[0][0]+1)/2 * 65535
        # look = look.cpu().numpy().astype(np.uint16)
        # success = cv2.imwrite("/home/jsw/Manydepth2-master/image_tosee/lookoptflow.png", look, [cv2.IMWRITE_PNG_COMPRESSION, 1])
        world_points_depth = self.backprojector_batch(depth, _invK)
        _, pix_locs_depth = self.projector_batch(world_points_depth, _K, lookup_pose)
        pix_locs_depth = pix_locs_depth.permute(0, 3, 1, 2)
        # --------------- backprojector_batch
        pix_coords = self.backprojector_batch.pix_coords.view(self.batch_size, 3, \
                                                              self.matching_height, self.matching_width)[:, :2, :, :]
        pix_coords = pix_coords[:flow.size(0)]
        normal_static_flow = (pix_locs_depth - pix_coords)
        normal_static_flow = self.normalize_flow(normal_static_flow )
        # look = (normal_static_flow[0][0]+1)/2 * 65535
        # look = look.cpu().numpy().astype(np.uint16)
        # success = cv2.imwrite("/home/jsw/Manydepth2-master/image_tosee/lookstaticflow.png", look, [cv2.IMWRITE_PNG_COMPRESSION, 1])
        dynamic_flow = flow - normal_static_flow
        check_flow = torch.norm(dynamic_flow, dim=1, keepdim=True)
        # check_flow = self.normalize_check_flow(check_flow)
        # look0=check_flow[0][0]
        # max_val =look0.max().item()
        # look = (look0 / max_val) * 65535
        # look = look.cpu().numpy().astype(np.uint16)
        # success = cv2.imwrite("/home/jsw/Manydepth2-master/image_tosee/lookcheckflow.png", look , [cv2.IMWRITE_PNG_COMPRESSION, 1])
        # print(success)
        threshold = 0.347
        motion_mask = check_flow < threshold
        return motion_mask

    def save_tensor_img(self, tensor, save_path='output.png'):
        """
        tensor: torch.Tensor, shape (C,H,W)
        save_path: 保存路径
        """
        # 1. 如果在GPU，先拉回CPU
        tensor = tensor.cpu()

        # 2. 如果值域不在[0,1]，做min-max归一化
        if tensor.max() > 1.0 or tensor.min() < 0.0:
            tensor = (tensor - tensor.min()) / (tensor.max() - tensor.min())

        # 3. 转成PIL并保存
        pil_img = TF.to_pil_image(tensor)
        pil_img.save(save_path)
        print(f"图片已保存到")

    def forward(self, inputs, outputs):
        motion_masks = {}
        with torch.no_grad():
            depth= outputs["depth",0,0]
            depth = F.interpolate(
            depth, [self.matching_height,self.matching_width], mode="bilinear", align_corners=False)
            for f_i in [1]:
                pose_feats = {f_i: inputs["color", f_i, 0] for f_i in self.frame_ids}
                # ----------------- FOWARD FLOW -----------------
                results_dict = self.model_gmflow(pose_feats[0] * 255., pose_feats[f_i] * 255.,
                                                 attn_splits_list=self.attn_splits_list,
                                                 corr_radius_list=self.corr_radius_list,
                                                 prop_radius_list=self.prop_radius_list)

                # img = pose_feats[0][0]
                # self.save_tensor_img(img, save_path=f'/home/jsw/Manydepth2-master/image_tosee/0.png')
                # lokimg = pose_feats[1][0]
                # self.save_tensor_img(lokimg, save_path=f'/home/jsw/Manydepth2-master/image_tosee/1.png')
                flow_preds = results_dict['flow_preds'][-1]
                outputs[("flow", f_i)] = flow_preds
            # this one is usually set as half of freeze epoch
            for fi in [-1, 1]:
                scale = 0
                poses = outputs["cam_T_cam", 0, fi]
                flow = outputs["flow", fi]
                # depth = outputs["depth", 0, scale]
                K = inputs["K", 0]
                invK = inputs["inv_K", 0]
                motion_masks[("ofrmask", fi, scale)]  = \
                    self.compute_dynamic_flow(poses, flow, depth, K, invK)

        return motion_masks
