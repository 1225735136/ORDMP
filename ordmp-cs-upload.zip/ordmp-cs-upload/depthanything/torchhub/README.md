# Local PyTorch Hub

This directory is for loading the DINOv2 encoder locally in case of no Internet connection.
