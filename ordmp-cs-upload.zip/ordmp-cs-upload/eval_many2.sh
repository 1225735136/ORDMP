python -m manydepth2.evaluate_depth_many2 \
    --data_path /root/autodl-tmp/kai/data/1_mgdepth/KITTI  \
    --load_weights_folder logs/models_many2/models/weights \
    --eval_mono 
